

public class run
{
  public static void main(String[] args)
  {
      Ex3 test = new Ex3();
    }
}